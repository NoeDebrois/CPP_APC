
#include "test.hpp"

int main() {

    test1(); // OK !
    test2(); // OK !
    test3(); // OK !
    test4(); // OK !
    test5(); // OK ! (computes the weighted sum)
    test6(); // OK ! (activates the weighted sum)
    test7();

    return 0;

}
